#HW2
#part 2
#Q4
import numpy as np
import scipy
import PIL
import matplotlib
import cv2
from scipy import signal

import os
os.chdir(".")
os.listdir(".")
from PIL import Image

img = cv2.imread('test.png',0)
Gx=np.array([[1,0,-1],[2,0,-2],[1,0,-1]])
Gy=np.array([[-1,-2,-1],[0,0,0],[1,2,1]])
Mx=signal.convolve2d(img,Gx)
My=signal.convolve2d(img,Gy)

M=np.sqrt(np.square(Mx)+np.square(My))
M=255*M/np.max(M)
M = np.array(M, dtype='uint8')
cv2.imshow("result",M)
cv2.waitKey(0)
cv2.imwrite("Q4result.png",M)

