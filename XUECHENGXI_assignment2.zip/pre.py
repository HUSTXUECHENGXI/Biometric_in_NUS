# HW2
# part 1
import numpy
import scipy
import PIL

import matplotlib
import os
os.chdir(".")
os.listdir(".")
from PIL import Image

img = Image.open('lena.jpg')

print(img.format , img.size , img.mode)

img.show()
from PIL import ImageEnhance 
enhancer = ImageEnhance.Contrast (img) 
enhanced_img = enhancer.enhance (2.0) 
enhanced_img.show()
enhanced_img.save('out.jpg')

import numpy as np 
img_array=np.asarray(img) 
img=Image.fromarray (img_array)