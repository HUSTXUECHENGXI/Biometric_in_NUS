#HW2
#part 2
#Q3
#Color space conversion.
# Use Python OpenCV functions to perform following operations 
# on ’bee.png’ and save the images. (5)
#• Read the image. 
#• Convert the image to HSV color space. 
#• Perform histogram equalization on V channel by cv2.equalizeHist(). 
#• Convert the result image to BGR color space. 
#• Show the image by cv2.imshow() and save the image.

import numpy as np
import scipy
import PIL
import matplotlib
import cv2

import os
os.chdir(".")
os.listdir(".")
from PIL import Image
img = cv2.imread("bee.png")
cv2.namedWindow("img1")
cv2.imshow("img1",img)

cv2.waitKey(0)

hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV) 
cv2.namedWindow("img2")
cv2.imshow("img2",hsv)
cv2.waitKey(0)

(h,s,v)=cv2.split(hsv)
cv2.imshow("v",v)
cv2.waitKey(0)
v1=cv2.equalizeHist(v)
hsvmerged=cv2.merge([h,s,v1])
cv2.imshow("hsvmerged",hsvmerged) 
cv2.waitKey(0)
result= cv2.cvtColor(hsvmerged,cv2.COLOR_HSV2BGR) 
cv2.imshow("result",result) 
cv2.waitKey(0)
cv2.imwrite("q3result.png",result)
