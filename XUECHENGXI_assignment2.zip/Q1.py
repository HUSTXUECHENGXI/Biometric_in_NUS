#HW2
#part 2
#Q1
# A = [1, 3, 2, 4; 2, 2, 3, 4; 5, 5, 4, 5; 8, 9, 0, 1],
# B = [1, 2, 3, 4; 2, 1, 3, 0; 4, 1, 3, 4; 2, 4, 3, 4].
# Please compute the convolution between A and B by hand. 
#They try to verify your answer by Python code.
# (Hint: from scipy import signal, use signal.convolve).
import numpy as np
import scipy
import PIL

import matplotlib
import os
os.chdir(".")
os.listdir(".")

from scipy import signal
A=np.array([[1, 3, 2, 4],[2, 2, 3, 4],[5, 5, 4, 5],[8, 9, 0, 1]])
B=np.array([[1, 2, 3, 4],[2, 1, 3, 0],[4, 1, 3, 4],[2, 4, 3, 4]])
c=signal.convolve(A,B)
print(c)

