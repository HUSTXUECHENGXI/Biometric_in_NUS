#HW2
#part 2
#Q2
#Study Numpy, Scipy, PIL and Matplotlib libraries. 
#Use lena.png to perform following operations and save the images: (11)
# • In the image, rotate a rectangular region by 45 degree counter-clockwise,
#whose vertices are (100,100), (100,400),(400,100),(400,400). (3) 
#• Perform histogram equalization on lena.png. Use matplotlib to plot the histogram ﬁgure for both original image and processed image. (3) 
#• Perform Max Filtering, Min Filtering, and Median Filter on lena.png. (3) 
#• Perform Gaussian Blur with sigma equal to 3 and 5. (2)

import numpy as np
import scipy
import PIL

#1
import matplotlib
import os
os.chdir(".")
os.listdir(".")
from PIL import Image
img = Image.open('lena.png')
print(img.format , img.size , img.mode)
box=(100,100,400,400)
region=img.crop(box)
region=region.rotate(45)
img.paste(region,box)
img.show()
img.save("rotate.png")

#2
import numpy as np 
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib.cm as cm

def myhis(image_array,image_bins=256):
    # 将图像矩阵转化成直方图数据，返回元组(频数，直方图区间坐标)
    image_array2,bins = np.histogram(image_array.flatten(),image_bins)
    # 计算直方图的累积函数
    cdf = image_array2.cumsum()
    # 将累积函数转化到区间[0,255]
    cdf = (255.0/cdf[-1])*cdf
    # 原图像矩阵利用累积函数进行转化，插值过程
    image2_array = np.interp(image_array.flatten(),bins[:-1],cdf)
    # 返回均衡化后的图像矩阵和累积函数
    return image2_array.reshape(image_array.shape),cdf
image_array = np.array(img)
plt.subplot(2,2,1)
plt.hist(image_array.flatten(),256)
plt.subplot(2,2,2)
plt.imshow(img,cmap=cm.gray)
plt.axis("off")
a = myhis(image_array)  # 利用刚定义的直方图均衡化函数对图像进行均衡化处理
plt.subplot(2,2,3)
plt.hist(a[0].flatten(),256)
plt.subplot(2,2,4)
plt.imshow(Image.fromarray(a[0]),cmap=cm.gray)
plt.axis("off")
plt.show()
plt.savefig("hist2.png")
#3
from PIL import ImageFilter as IF
im1 = img.filter(IF.MaxFilter)
im2 = img.filter(IF.MinFilter)  
im3 = img.filter(IF.MedianFilter)
im1.show()
im2.show()
im3.show()
im1.save("im1.png")
im2.save("im2.png")
im3.save("im3.png")

#4
im4 = img.filter(IF.GaussianBlur(3))
im5 = img.filter(IF.GaussianBlur(5))
im4.show()
im5.show()
im4.save("im4.png")
im5.save("im5.png")