
from PIL import Image 
from PIL import ImageOps 
import numpy 
from numpy import linalg 
import matplotlib 
import matplotlib.pyplot as plt
import cv2

flower = Image.open("flower.jpg")
gflower = ImageOps.grayscale(flower)
aflower = numpy.asarray(gflower) # aflower is unit8 
aflower = numpy.float32(aflower)
U,S,Vt = linalg.svd(aflower)
plt.plot(S,'b.')
plt.savefig('table.png')
plt.subplot(2,3,1)
plt.plot(S,'b.')


K = 20 
Sk = numpy.diag(S[:K]) 
Uk = U[:, :K] 
Vtk = Vt[:K, :]

aImk = numpy.dot(Uk, numpy.dot( Sk, Vtk)) 
Imk = Image.fromarray(aImk) 

plt.subplot(2,3,2)
plt.title('flower')
plt.imshow(flower)
plt.axis("off")
plt.subplot(2,3,3)
flower.save('flower.png')
plt.title('K=20')
plt.imshow(Imk)
plt.axis("off")
Imk = Imk.convert('RGB')
Imk.save('Imk.png')


K = 50 
Sk = numpy.diag(S[:K]) 
Uk = U[:, :K] 
Vtk = Vt[:K, :]

aImk1 = numpy.dot(Uk, numpy.dot( Sk, Vtk)) 
Imk1 = Image.fromarray(aImk1) 
plt.subplot(2,3,4)
plt.title('K=50')
plt.imshow(Imk1)
plt.axis("off")
Imk1 = Imk1.convert('RGB')
Imk1.save('Imk1.png')
K = 100
Sk = numpy.diag(S[:K]) 
Uk = U[:, :K] 
Vtk = Vt[:K, :]

aImk2 = numpy.dot(Uk, numpy.dot( Sk, Vtk)) 
Imk2 = Image.fromarray(aImk2) 
plt.subplot(2,3,5)
plt.title('K=100')
plt.imshow(Imk2)
plt.axis("off")
Imk2 = Imk2.convert('RGB')
Imk2.save('Imk2.png')
K = 200
Sk = numpy.diag(S[:K]) 
Uk = U[:, :K] 
Vtk = Vt[:K, :]

aImk3 = numpy.dot(Uk, numpy.dot( Sk, Vtk)) 
Imk3 = Image.fromarray(aImk3) 
plt.subplot(2,3,6)
plt.title('K=200')
plt.imshow(Imk3)
plt.axis("off")
Imk3 = Imk3.convert('RGB')
Imk3.save('Imk3.png')
plt.savefig("result.png")
plt.show()